This is the submission of group 2 for the second project of Big Data and Computer Security.
The label file for the first implemented algorithm (classifier approach) is spam-mail.tt.algorithm1.label .
The obtained prediction accuracy with this label file is 0.81335.
The label file for the second implemented algorithm (anomaly-detection approach) is spam-mail.tt.algorithm2.label .
The obtained prediction accuracy with this label file is 0.67268.
